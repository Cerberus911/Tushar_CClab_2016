This is my CC_Lab Final Project. 

Sine is a game created to help players understand the basics of sound through modulation of a sinewave.
The game is a 2d platformer.

Link to demo: https://youtu.be/qqJ4Ost-Im4