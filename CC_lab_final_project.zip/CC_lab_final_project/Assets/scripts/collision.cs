﻿using UnityEngine;
using System.Collections;

public class collision : MonoBehaviour {

    public Rigidbody2D rb;
    public float thrust;
    public bool hitGround;
    public float jumpFactor;

	// Use this for initialization
	void Start () {
        rb = GetComponent<Rigidbody2D>();

        thrust = 300f;
        jumpFactor = 500f;
	}
	
	// Update is called once per frame
	void Update () {

        

        if (Input.GetAxisRaw("moveright") > 0) {
            rb.AddForce(Vector2.right * 3f);
        }

        if (Input.GetAxisRaw("moveleft") > 0)
        {
            rb.AddForce(Vector2.left * 3f);
        }

        if (Input.GetAxisRaw("amp") < 0 && thrust < 900)
        {
            //rb.gravityScale += 0.05f;
            thrust += 10f;

        }

        if (Input.GetAxisRaw("amp") > 0 && thrust > 100)
        {
            //rb.gravityScale -= 0.05f;
            thrust -= 10f;
        }

        if (Input.GetAxis("freq") > 0 && rb.gravityScale > 1f)
        {
           
            rb.gravityScale -= 0.05f;
            thrust -= 10f;
        }

        if (Input.GetAxis("freq") < 0)
        {
            rb.gravityScale += 0.05f;
            thrust += 10f;
        }

      

     

    }


    void OnCollisionEnter2D(Collision2D other)
    {

        if (other.gameObject.tag == "ground")
        {

            rb.AddForce(Vector2.up * thrust);
            hitGround = true;

            
        }

        if (other.gameObject.tag == "LevelChange")
        {

            Application.LoadLevel(1);

        }

        if (other.gameObject.tag == "LevelChange2")
        {

            Application.LoadLevel(2);

        }


        if(other.gameObject.tag == "Respawn")
        {

            Application.LoadLevel(1);

        }

        if (other.gameObject.tag == "Respawn2")
        {

            Application.LoadLevel(2);

        }




    }



    }

 


