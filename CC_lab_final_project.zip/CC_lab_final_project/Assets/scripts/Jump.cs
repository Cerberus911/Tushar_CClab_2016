﻿using UnityEngine;
using System.Collections;

public class Jump : MonoBehaviour
{

    Vector3 startPos;

    public float frequency = 0.5f;
    public float amplitude = 10.5f;
    public float speed = 3f;

    public Rigidbody2D rb;
    public float gravity;
    private Vector3 axis;
    private Vector3 pos;
    // Use this for initialization

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();

        gravity = GetComponent<Rigidbody2D>().gravityScale;
    }

    void Start()
    {

        //pos = transform.position;
        //axis = transform.up;
      
    }

    // Update is called once per frame
    void Update()
    {

        Movement();

        //float theta = Time.timeSinceLevelLoad / period;
        //float distance = amplitude * Mathf.Sin(theta);
        //transform.position = startPos + Vector3.up * distance;

        //transform.position = pos + axis * Mathf.Sin(Time.time * frequency) * amplitude;
    }

    void FixedUpdate()
    {
        if (Input.GetAxis("move") >= 0)
        {
           rb.velocity = new Vector2(speed , 0f);
        }
    }

    void Movement()
    {
        if (Input.GetAxis("amp") > 0 && amplitude > 0)
        {
         
            amplitude -=0.15f;
        }

        if (Input.GetAxis("amp") < 0 && amplitude < 14)
        {
        
            amplitude += 0.15f;
        }

        if (Input.GetAxis("freq") > 0 && frequency > 0)
        {
        
            frequency -= 0.05f;
        }

        if (Input.GetAxis("freq") < 0)
        {
     
            frequency += 0.05f;
        }

      
    }


   
}